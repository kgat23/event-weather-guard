package com.assignment.weatherguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherGuardApplication {

    public static void main(String[] args) {
        SpringApplication.run(WeatherGuardApplication.class, args);
    }

}