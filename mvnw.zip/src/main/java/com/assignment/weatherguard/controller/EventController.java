package com.assignment.weatherguard.controller;

import com.assignment.weatherguard.model.EventRequest;
import com.assignment.weatherguard.model.EventResponse;
import com.assignment.weatherguard.service.WeatherService;
import org.springframework.web.bind.annotation.*;

@RestController
public class EventController {

    private final WeatherService service;

    public EventController(WeatherService service) {
        this.service = service;
    }

    @PostMapping("/event-forecast")
    public EventResponse getForecast(@RequestBody EventRequest request) {
        return service.analyzeEvent(request);
    }
}