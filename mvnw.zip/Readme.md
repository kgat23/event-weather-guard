# Event Weather Guard 🌦️

A Spring Boot backend service that analyzes weather forecasts to determine if outdoor events are **Safe**, **Risky**, or **Unsafe**.

## 🚀 Features
- **Deterministic Risk Analysis:** Classifies events based on rain, wind, and WMO weather codes.
- **Detailed Explainability:** Provides specific reasons (e.g., "Wind > 30km/h at 15:00") for any risk.
- **Time-Zone Aware:** Auto-adjusts forecast queries to the event location's local time.
- **OpenAPI / Swagger:** Includes auto-generated API documentation.

---

## 🛠️ Setup & Run

### Prerequisites
- Java 17+
- Internet connection (to fetch data from OpenMeteo)

### Installation
1. Clone this repository or unzip the code.
2. Open a terminal in the project root.

### Running the App
**Mac / Linux:**
```bash
./mvnw spring-boot:run